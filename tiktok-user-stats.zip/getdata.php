<?php
require __DIR__ . '/src/Users.php';
$getTiktokUser = new TikTok\Users();
?>